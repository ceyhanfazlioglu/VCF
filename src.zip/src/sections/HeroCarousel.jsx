import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const HeroCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      season: 'SUMMER 2026',
      title: 'NEW COLLECTION',
      description: 'We know how large objects will act, but things on a small scale.',
      image: '/assets/hero-woman-2.png',
    },
    {
      id: 2,
      season: 'SUMMER 2026',
      title: 'NEW COLLECTION',
      description: 'We know how large objects will act, but things on a small scale.',
      image: '/assets/hero-woman.jpg',
    },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="relative w-full h-[500px] md:h-[600px] lg:h-[716px] bg-[#23A6F0]">
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-500 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          {/* Background Image - Positioned Right */}
          <div className="absolute inset-0 flex justify-end">
            <img 
              src={slide.image} 
              alt="Hero"
              className="h-full w-auto object-cover object-top"
            />
          </div>

          {/* Content */}
          <div className="absolute inset-0">
            <div className="container mx-auto px-4 h-full">
              <div className="flex items-center h-full">
                <div className="text-white space-y-6 max-w-xl">
                  <h5 className="text-sm md:text-base font-bold tracking-wider">
                    {slide.season}
                  </h5>
                  <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                    {slide.title}
                  </h1>
                  <p className="text-base md:text-xl text-white/90">
                    {slide.description}
                  </p>
                  <button className="bg-[#2DC071] hover:bg-[#26a55f] text-white px-8 md:px-10 py-3 md:py-4 rounded font-bold text-sm md:text-base transition-colors">
                    SHOP NOW
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation */}
      <button
        onClick={prevSlide}
        className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 text-white hover:text-white/80 transition-colors z-20"
      >
        <ChevronLeft className="w-10 h-10 md:w-12 md:h-12" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 text-white hover:text-white/80 transition-colors z-20"
      >
        <ChevronRight className="w-10 h-10 md:w-12 md:h-12" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-16 h-2 rounded-full transition-colors ${
              index === currentSlide ? 'bg-white' : 'bg-white/50'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroCarousel;