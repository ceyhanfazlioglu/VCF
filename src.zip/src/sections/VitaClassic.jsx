import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const VitaClassic = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const products = [
    {
      id: 1,
      season: 'SUMMER 2020',
      title: 'Vita Classic Product',
      description: 'We know how large objects will act, We know how are objects will act, We know',
      price: '$16.48',
      image: '/assets/products/product-8.jpg',
      bgColor: 'bg-[#23856D]',
    },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % products.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + products.length) % products.length);
  };

  return (
    <section className="relative overflow-hidden">
      <div className="container mx-auto px-4 py-12 md:py-0">
        {/* Figma: 1049×599px container */}
        <div className="max-w-[1049px] mx-auto">
          {products.map((product, index) => (
            <div
              key={product.id}
              className={`transition-opacity duration-500 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0 hidden'
              }`}
            >
              <div className={`${product.bgColor} rounded-lg overflow-hidden`}>
                {/* Mobile: Stack vertical */}
                <div className="flex flex-col md:flex-row md:h-[599px]">
                  {/* Left Content - Figma: 509×432px */}
                  <div className="flex items-center justify-center p-8 md:p-0 md:w-[509px]">
                    <div className="text-white space-y-6 max-w-md">
                      <h5 className="text-sm md:text-base font-bold tracking-wider">
                        {product.season}
                      </h5>
                      <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">
                        {product.title}
                      </h2>
                      <p className="text-sm md:text-base text-white/90">
                        {product.description}
                      </p>
                      
                      <div className="flex items-center gap-6">
                        <span className="text-xl md:text-2xl font-bold">{product.price}</span>
                        <button className="bg-[#2DC071] hover:bg-[#26a55f] text-white px-8 py-3 rounded font-bold text-sm transition-colors">
                          ADD TO CART
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right Image - Figma: 443×685px */}
                  <div className="md:w-[443px] flex items-end justify-center">
                    <img 
                      src={product.image} 
                      alt={product.title}
                      className="w-full h-[400px] md:h-[685px] object-cover object-top"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Navigation Arrows - Only show if multiple slides */}
          {products.length > 1 && (
            <>
              <button
                onClick={prevSlide}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:text-white/80 transition-colors z-10"
              >
                <ChevronLeft className="w-10 h-10 md:w-12 md:h-12" />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:text-white/80 transition-colors z-10"
              >
                <ChevronRight className="w-10 h-10 md:w-12 md:h-12" />
              </button>

              {/* Dots Indicator */}
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-10">
                {products.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-16 h-2 rounded-full transition-colors ${
                      index === currentSlide ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default VitaClassic;