import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from "redux-thunk";

const rootReducer = combineReducers({
  // reducers burada
});

export const store = createStore(rootReducer, applyMiddleware(thunk));
