export default function NotFound() {
    return <div className="p-10 text-xl font-semibold">404 | Not Found</div>;
  }
  